# SKARRA AI V6

SKARRA AI is a multi-model Android AI workspace with a server-side provider router.

## What's new in V5
- Version 6.0 / versionCode 6.
- Added a backend health-check button in Settings.
- Fixed backend health/version reporting to 6.0.
- Release build configuration with code/resource shrinking.
- Safer release manifest settings.
- Backend URL can be changed from in-app Settings instead of being permanently hard-coded.
- Clear separation between the Android app and provider API credentials.
- Chat, model-mode selection, local conversation history, and feature surfaces for Web/Files/Images/Code.

## Current architecture
Android app -> HTTPS SKARRA backend -> permitted AI model/provider endpoints.

The backend must keep provider API keys server-side. Do not put provider keys in the APK.

## Run the backend
Requires Node.js 20+.

```bash
cd backend
cp .env.example .env
npm install
npm start
```

The backend expects an OpenAI-compatible `/v1/chat/completions` endpoint. Configure the provider values in `.env`.

## Run Android
Open the `android/` folder in Android Studio, let Gradle sync, then run the debug build on an emulator/device.

For a production deployment, open SKARRA Settings and set the backend URL to your HTTPS server.

## Release
Google recommends an Android App Bundle (AAB) for Play distribution. Create a release signing key and keep its credentials private. Do not commit keystores, API keys, or passwords.

Before publishing, complete Play Console policy declarations, privacy/data-safety information, store listing assets, testing, and developer verification as applicable.

## Important
This is a real project foundation, not a finished hosted AI service. A live model provider and production backend still need to be configured. Check the exact license/terms of every model or service before commercial distribution.
