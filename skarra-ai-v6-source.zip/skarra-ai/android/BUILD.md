# Building SKARRA AI V6

Open this `android/` folder in Android Studio and let Gradle sync.

For Play release, create a signed Android App Bundle (`.aab`) using Android Studio's **Build > Generate Signed Bundle / APK** flow.

The project targets Android 16 / API 36.
