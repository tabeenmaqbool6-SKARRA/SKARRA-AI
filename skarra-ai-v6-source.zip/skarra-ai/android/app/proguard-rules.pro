# SKARRA AI release rules.
# Keep this file intentionally small; add provider-specific rules only when required.
