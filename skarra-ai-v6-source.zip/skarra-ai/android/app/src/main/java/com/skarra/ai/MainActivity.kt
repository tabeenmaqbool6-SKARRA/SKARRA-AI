package com.skarra.ai

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

private data class ChatMessage(val role: String, val content: String)
private val client = OkHttpClient()
private const val DEFAULT_BACKEND_URL = "http://10.0.2.2:8787"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SkarraApp(this) }
    }
}

@Composable
private fun SkarraApp(context: Context) {
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("skarra", Context.MODE_PRIVATE) }
    var input by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(prefs.getString("mode", "auto") ?: "auto") }
    var busy by remember { mutableStateOf(false) }
    var tool by remember { mutableStateOf("Chat") }
    var messages by remember { mutableStateOf(loadMessages(prefs)) }
    var backendUrl by remember { mutableStateOf(prefs.getString("backend_url", DEFAULT_BACKEND_URL) ?: DEFAULT_BACKEND_URL) }
    var showSettings by remember { mutableStateOf(false) }
    var connectionStatus by remember { mutableStateOf<String?>(null) }
    var testingConnection by remember { mutableStateOf(false) }

    MaterialTheme {
        Scaffold(topBar = {
            TopAppBar(
                title = { Column { Text("SKARRA AI"); Text("Multi-model workspace", style = MaterialTheme.typography.labelSmall) } },
                actions = {
                    TextButton(onClick = { showSettings = true }) { Text("Settings") }
                    TextButton(onClick = { messages = listOf(ChatMessage("assistant", "New SKARRA chat started.")); saveMessages(prefs, messages) }) { Text("New") }
                }
            )
        }) { pad ->
            Column(Modifier.padding(pad).fillMaxSize().padding(14.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Chat", "Web", "Files", "Images", "Code").forEach { t ->
                        FilterChip(selected = tool == t, onClick = { tool = t }, label = { Text(t) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Model")
                    listOf("auto", "fast", "reasoning", "open").forEach { item ->
                        FilterChip(selected = mode == item, onClick = { mode = item; prefs.edit().putString("mode", item).apply() }, label = { Text(item.replaceFirstChar { it.uppercase() }) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                if (tool != "Chat") {
                    Surface(tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
                        Text("$tool is prepared as a feature surface. Connect its backend tool when you implement that capability.", Modifier.padding(12.dp))
                    }
                    Spacer(Modifier.height(8.dp))
                }
                LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                    items(messages) { m ->
                        Surface(Modifier.fillMaxWidth().padding(vertical = 5.dp), tonalElevation = 2.dp) {
                            Column(Modifier.padding(12.dp)) {
                                Text(if (m.role == "user") "You" else "SKARRA", style = MaterialTheme.typography.labelMedium)
                                Spacer(Modifier.height(3.dp))
                                Text(m.content)
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                    OutlinedTextField(value = input, onValueChange = { input = it }, Modifier.weight(1f), placeholder = { Text("Ask SKARRA...") }, minLines = 1, maxLines = 5)
                    Button(enabled = !busy && input.isNotBlank(), onClick = {
                        val q = input.trim(); input = ""
                        val updated = messages + ChatMessage("user", q)
                        messages = updated; saveMessages(prefs, updated); busy = true
                        scope.launch {
                            val answer = sendToBackend(backendUrl, updated, mode, tool)
                            val done = messages + ChatMessage("assistant", answer)
                            messages = done; saveMessages(prefs, done); busy = false
                        }
                    }) { Text(if (busy) "…" else "Send") }
                }
                Spacer(Modifier.height(8.dp))
                Text("SKARRA • Your AI workspace", style = MaterialTheme.typography.labelMedium)
            }
        }

        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("SKARRA settings") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Backend URL")
                        OutlinedTextField(value = backendUrl, onValueChange = { backendUrl = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Text("For production, use an HTTPS backend URL. Local emulator testing can use http://10.0.2.2:8787. Never put provider API keys in this app.", style = MaterialTheme.typography.bodySmall)
                        connectionStatus?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                    }
                },
                confirmButton = {
                    Row {
                        TextButton(enabled = !testingConnection, onClick = {
                            val url = backendUrl.trim().trimEnd('/')
                            testingConnection = true
                            connectionStatus = "Testing…"
                            scope.launch {
                                connectionStatus = testBackend(url)
                                testingConnection = false
                            }
                        }) { Text(if (testingConnection) "Testing…" else "Test") }
                        TextButton(onClick = { prefs.edit().putString("backend_url", backendUrl.trim().trimEnd('/')).apply(); showSettings = false }) { Text("Save") }
                    }
                }
            )
        }
    }
}

private suspend fun sendToBackend(baseUrl: String, messages: List<ChatMessage>, mode: String, tool: String): String = withContext(Dispatchers.IO) {
    try {
        val arr = JSONArray()
        messages.takeLast(30).forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject().put("messages", arr).put("mode", mode).put("tool", tool.lowercase()).toString()
            .toRequestBody("application/json".toMediaType())
        val req = Request.Builder().url("${baseUrl.trimEnd('/')}/v1/chat").post(body).build()
        client.newCall(req).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) return@withContext "Error: ${try { JSONObject(raw).optString("error", "Request failed") } catch (_: Exception) { "Request failed" }}"
            JSONObject(raw).optString("text", "No response")
        }
    } catch (_: Exception) {
        "Could not reach SKARRA server. Check Settings → Backend URL and your network connection."
    }
}

private suspend fun testBackend(baseUrl: String): String = withContext(Dispatchers.IO) {
    return@withContext try {
        val req = Request.Builder().url("${baseUrl.trimEnd('/')}/health").get().build()
        client.newCall(req).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) return@withContext "Connection failed (${response.code})"
            val json = JSONObject(raw)
            if (json.optBoolean("ok", false)) "Connected to ${json.optString("name", "SKARRA AI")} ${json.optString("version", "")}"
            else "Server responded, but health check failed"
        }
    } catch (_: Exception) {
        "Could not connect. Check the URL, server, and network."
    }
}

private fun loadMessages(prefs: android.content.SharedPreferences): List<ChatMessage> {
    val raw = prefs.getString("messages", null) ?: return listOf(ChatMessage("assistant", "Welcome to SKARRA AI. Ask me anything."))
    return try {
        val a = JSONArray(raw)
        (0 until a.length()).map { ChatMessage(a.getJSONObject(it).getString("role"), a.getJSONObject(it).getString("content")) }
    } catch (_: Exception) { listOf(ChatMessage("assistant", "Welcome to SKARRA AI. Ask me anything.")) }
}

private fun saveMessages(prefs: android.content.SharedPreferences, messages: List<ChatMessage>) {
    val a = JSONArray()
    messages.takeLast(100).forEach { a.put(JSONObject().put("role", it.role).put("content", it.content)) }
    prefs.edit().putString("messages", a.toString()).apply()
}
