import http from 'node:http';
import { URL } from 'node:url';

const PORT = Number(process.env.PORT || 8787);
const MAX_BODY = 2 * 1024 * 1024;
const PROVIDERS = {
  fast: { url: process.env.FAST_MODEL_URL || process.env.MODEL_URL, key: process.env.FAST_MODEL_API_KEY || process.env.MODEL_API_KEY, model: process.env.FAST_MODEL_NAME || process.env.MODEL_NAME },
  reasoning: { url: process.env.REASONING_MODEL_URL || process.env.MODEL_URL, key: process.env.REASONING_MODEL_API_KEY || process.env.MODEL_API_KEY, model: process.env.REASONING_MODEL_NAME || process.env.MODEL_NAME },
  open: { url: process.env.OPEN_MODEL_URL || process.env.MODEL_URL, key: process.env.OPEN_MODEL_API_KEY || process.env.MODEL_API_KEY, model: process.env.OPEN_MODEL_NAME || process.env.MODEL_NAME }
};

function send(res, status, body) { res.writeHead(status, {'Content-Type':'application/json','Access-Control-Allow-Origin':'*'}); res.end(JSON.stringify(body)); }
function read(req) { return new Promise((resolve,reject)=>{ let b=''; req.on('data',c=>{b+=c; if(b.length>MAX_BODY){req.destroy(); reject(new Error('Request too large'));}}); req.on('end',()=>{try{resolve(JSON.parse(b||'{}'))}catch(e){reject(new Error('Invalid JSON'))}}); req.on('error',reject); }); }
function choose(mode){ if(mode==='fast'||mode==='reasoning'||mode==='open') return mode; return 'fast'; }
async function callProvider(p, payload) {
  if(!p.url || !p.key || !p.model) throw new Error('No model provider configured. Add the provider settings in backend/.env.');
  const r = await fetch(p.url, { method:'POST', headers:{'Content-Type':'application/json','Authorization':`Bearer ${p.key}`}, body:JSON.stringify({model:p.model,messages:payload.messages,temperature:payload.mode==='reasoning'?0.2:0.7,stream:false}) });
  const raw=await r.text();
  if(!r.ok) throw new Error(`Provider ${r.status}: ${raw.slice(0,300)}`);
  const d=JSON.parse(raw);
  return d.choices?.[0]?.message?.content ?? d.output_text ?? d.text ?? 'No response returned.';
}
const server=http.createServer(async(req,res)=>{
  if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'GET,POST,OPTIONS'});return res.end();}
  const u=new URL(req.url,`http://${req.headers.host}`);
  if(req.method==='GET'&&u.pathname==='/health') return send(res,200,{ok:true,name:'SKARRA AI',version:'6.0',configured:Object.fromEntries(Object.entries(PROVIDERS).map(([k,v])=>[k,Boolean(v.url&&v.key&&v.model)]))});
  if(req.method==='POST'&&u.pathname==='/v1/chat'){
    try{const p=await read(req); if(!Array.isArray(p.messages)||p.messages.length===0)return send(res,400,{error:'messages must be a non-empty array'}); const selected=choose(p.mode); const text=await callProvider(PROVIDERS[selected],p); return send(res,200,{text,mode:selected,tool:p.tool||'chat'});}catch(e){return send(res,502,{error:e.message||'Provider error'});}
  }
  send(res,404,{error:'Not found'});
});
server.listen(PORT,()=>console.log(`SKARRA AI backend v6 listening on ${PORT}`));
